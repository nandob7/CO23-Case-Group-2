class Tool:
    def __init__(self, tid, size, max_no, cost):
        self.tid = tid
        self.size = size
        self.max_no = max_no
        self.cost = cost
